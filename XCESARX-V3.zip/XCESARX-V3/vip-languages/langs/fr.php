<?php

//FRENSH LANGUAGE
 
$title = "Connectez-vous à votre compte";
$continue = "Continuer";
$myaccount = "Mon compte";
$privacy = "Intimité";
$legal = "Légal";
$contact = "Contactez nous";
$worldwide = "Worldwide";
$feedback = "rétroaction";
$skip = "Sauter";
$email = "Email";
$password = "Mot de passe";
$login = "Connexion";
$signup = "Créer un compte";
$logout = "Déconnexion"; 
$forgot = "Mot de passe oublié ?";
$required = "Champs obligatoires";
$wrong_email = "Ce format d'email n'est pas correct";
$incorrect = "Certaines de vos informations ne sont pas correctes. Veuillez réessayer.";
$or = "ou";
$biling_title = "Mettre à jour la facturation d'adresse"; 
$continue_to_paypal = "Continuer vers Paypal";
$copyright = "© 1999-2019 , Tous les droits sont réservés.";

?>