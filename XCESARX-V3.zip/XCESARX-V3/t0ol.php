<?php

//your email here 
$your_email = 'Put-Your-Email-Here'; 

//your password here 
$pass = '010203';

//your username
$name = 'XCESARX';


?>